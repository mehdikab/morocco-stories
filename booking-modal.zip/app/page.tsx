"use client"

import { useState } from "react"
import Header from "@/components/header"
import BookingModal from "@/components/booking-modal"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Heart,
  Users,
  UserCheck,
  Clock,
  MapPin,
  Star,
  ArrowRight,
  Shield,
  Award,
  Headphones,
  CheckCircle,
  XCircle,
  ChevronDown,
  Phone,
  Mail,
  MessageSquare,
} from "lucide-react"

// Sample data
const tourPackages = [
  {
    id: 1,
    title: "Northern Coast, Dunes & Chefchaouen",
    subtitle: "Coastal adventure with blue city charm",
    description: "Experience Morocco's stunning northern coastline and the famous blue city of Chefchaouen.",
    price: "$599",
    duration: "5 Days / 4 Nights",
    rating: "4.8",
    category: "coastal",
    image: "/placeholder.svg?height=300&width=400&text=Northern+Coast",
    highlights: ["Chefchaouen Blue City", "Atlantic Coast", "Rif Mountains", "Traditional Markets"],
    route: "Tangier → Chefchaouen → Tetouan → Asilah",
  },
  {
    id: 2,
    title: "Imperial Cities & Atlas Foothills",
    subtitle: "Historic cities and mountain landscapes",
    description: "Discover Morocco's imperial heritage and stunning Atlas Mountain foothills.",
    price: "$699",
    duration: "6 Days / 5 Nights",
    rating: "4.9",
    category: "cultural",
    image: "/placeholder.svg?height=300&width=400&text=Imperial+Cities",
    highlights: ["Fes Medina", "Meknes", "Atlas Mountains", "Berber Villages"],
    route: "Fes → Meknes → Ifrane → Atlas Mountains",
  },
  {
    id: 3,
    title: "City Lights Chefchaouen",
    subtitle: "Blue city evening magic",
    description: "Experience the enchanting blue city of Chefchaouen during golden hour and evening.",
    price: "$299",
    duration: "2 Days / 1 Night",
    rating: "4.7",
    category: "express",
    image: "/placeholder.svg?height=300&width=400&text=Chefchaouen+Lights",
    highlights: ["Blue City Streets", "Mountain Views", "Local Crafts", "Traditional Cuisine"],
    route: "Chefchaouen city tour with mountain excursion",
  },
  {
    id: 4,
    title: "The Classic Trilogy Sahara Loop",
    subtitle: "Desert adventure with imperial cities",
    description: "The ultimate Morocco experience combining desert adventure with historic imperial cities.",
    price: "$899",
    duration: "8 Days / 7 Nights",
    rating: "4.9",
    category: "adventure",
    image: "/placeholder.svg?height=300&width=400&text=Sahara+Loop",
    highlights: ["Sahara Desert", "Camel Trekking", "Imperial Cities", "Atlas Mountains"],
    route: "Marrakech → Fes → Merzouga → Ouarzazate → Marrakech",
  },
  {
    id: 5,
    title: "City Lights Two Days Marrakech",
    subtitle: "Red city intensive experience",
    description: "Immerse yourself in the vibrant energy of Marrakech's medina and modern quarters.",
    price: "$399",
    duration: "2 Days / 1 Night",
    rating: "4.6",
    category: "express",
    image: "/placeholder.svg?height=300&width=400&text=Marrakech+Lights",
    highlights: ["Jemaa el-Fnaa", "Majorelle Garden", "Souks", "Bahia Palace"],
    route: "Marrakech medina and modern city exploration",
  },
  {
    id: 6,
    title: "City Lights Casablanca",
    subtitle: "Modern Morocco's economic heart",
    description: "Discover the cosmopolitan charm of Morocco's largest city and economic center.",
    price: "$349",
    duration: "2 Days / 1 Night",
    rating: "4.5",
    category: "urban",
    image: "/placeholder.svg?height=300&width=400&text=Casablanca",
    highlights: ["Hassan II Mosque", "Corniche", "Art Deco Architecture", "Modern Districts"],
    route: "Casablanca city tour with coastal exploration",
  },
]

const activities = [
  {
    id: 1,
    title: "Desert Camel Trekking",
    subtitle: "Authentic Sahara experience",
    description: "Trek through golden dunes on camelback and camp under the stars.",
    price: "$199",
    duration: "1 Day",
    rating: "4.8",
    category: "adventure",
    image: "/placeholder.svg?height=200&width=300&text=Camel+Trekking",
    highlights: ["Camel Ride", "Desert Camp", "Stargazing", "Berber Culture"],
    route: "Merzouga dunes expedition",
  },
  {
    id: 2,
    title: "Cooking Class Experience",
    subtitle: "Learn traditional Moroccan cuisine",
    description: "Master the art of Moroccan cooking with local chefs in authentic settings.",
    price: "$89",
    duration: "4 Hours",
    rating: "4.9",
    category: "cultural",
    image: "/placeholder.svg?height=200&width=300&text=Cooking+Class",
    highlights: ["Tagine Cooking", "Spice Market Visit", "Traditional Recipes", "Family Meal"],
    route: "Local family home or cooking school",
  },
  {
    id: 3,
    title: "Hot Air Balloon Buffet Experience",
    subtitle: "Luxury hot air balloon flight with gourmet buffet breakfast served in the sky",
    description: "Soar above Morocco's landscapes while enjoying a gourmet breakfast experience.",
    price: "$288",
    duration: "3 Hours",
    rating: "4.5",
    category: "adventure",
    image: "/placeholder.svg?height=200&width=300&text=Hot+Air+Balloon",
    highlights: ["Marrakech", "Ait Ben Haddou", "Dades Valley", "Sahara Desert"],
    route: "Marrakech → Dades → Merzouga (+ flexible endings)",
  },
  {
    id: 4,
    title: "Atlas Mountains Hiking",
    subtitle: "Mountain adventure and Berber villages",
    description: "Hike through stunning Atlas Mountain landscapes and visit traditional Berber villages.",
    price: "$149",
    duration: "Full Day",
    rating: "4.7",
    category: "adventure",
    image: "/placeholder.svg?height=200&width=300&text=Atlas+Hiking",
    highlights: ["Mountain Trails", "Berber Villages", "Waterfalls", "Local Lunch"],
    route: "Atlas Mountains day trek from Marrakech",
  },
]

const hotels = [
  {
    id: 1,
    city: "Marrakech",
    name: "La Villa des Orangers",
    description: "Luxury riad in the heart of Marrakech medina with traditional architecture and modern amenities.",
    price: "$299",
    rating: "4.8",
    image: "/placeholder.svg?height=200&width=300&text=Villa+des+Orangers",
    amenities: ["Pool", "Spa", "Restaurant", "WiFi"],
  },
  {
    id: 2,
    city: "Marrakech",
    name: "Riad Kheirredine",
    description: "Authentic riad experience with beautiful courtyard and rooftop terrace overlooking the medina.",
    price: "$189",
    rating: "4.6",
    image: "/placeholder.svg?height=200&width=300&text=Riad+Kheirredine",
    amenities: ["Rooftop Terrace", "Traditional Decor", "Breakfast", "WiFi"],
  },
  {
    id: 3,
    city: "Casablanca",
    name: "Royal Mansour Casablanca",
    description: "Luxury beachfront hotel with stunning ocean views and world-class amenities.",
    price: "$459",
    rating: "4.9",
    image: "/placeholder.svg?height=200&width=300&text=Royal+Mansour",
    amenities: ["Beach Access", "Spa", "Multiple Restaurants", "Pool"],
  },
  {
    id: 4,
    city: "Fes",
    name: "Hotel Sahrai",
    description: "Modern luxury hotel overlooking the ancient medina of Fes with contemporary design.",
    price: "$329",
    rating: "4.7",
    image: "/placeholder.svg?height=200&width=300&text=Hotel+Sahrai",
    amenities: ["City Views", "Modern Design", "Pool", "Restaurant"],
  },
]

export default function HomePage() {
  const [selectedTour, setSelectedTour] = useState(null)
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false)
  const [openFAQ, setOpenFAQ] = useState<number | null>(null)

  const handleBookTour = (tour: any) => {
    setSelectedTour(tour)
    setIsBookingModalOpen(true)
  }

  const handleBookingComplete = (bookingData: any) => {
    console.log("Booking completed:", bookingData)
    alert(`Booking confirmed for ${bookingData.travelers} travelers on ${bookingData.selectedDate}!`)
    setIsBookingModalOpen(false)
  }

  const faqs = [
    {
      question: "What's included in the tour price?",
      answer:
        "Our tours include accommodation, transportation, professional guide, entrance fees to attractions, and most meals as specified in the itinerary.",
    },
    {
      question: "Can I customize my itinerary?",
      answer:
        "Yes! We offer flexible itineraries that can be customized to your preferences, interests, and travel dates.",
    },
    {
      question: "What's the best time to visit Morocco?",
      answer:
        "Morocco can be visited year-round. Spring (March-May) and fall (September-November) offer the most comfortable weather.",
    },
    {
      question: "Is Morocco safe for tourists?",
      answer:
        "Morocco is generally very safe for tourists. We provide 24/7 support and work with licensed local guides for your safety and peace of mind.",
    },
    {
      question: "Do you offer group discounts?",
      answer: "Yes! We offer discounts for couples (15% off), groups of 5+ (25% off), and groups of 10+ (30% off).",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden">
        {/* Background Mosaic */}
        <div className="absolute inset-0 grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-0">
          {Array.from({ length: 32 }).map((_, i) => (
            <div
              key={i}
              className="relative overflow-hidden"
              style={{
                backgroundImage: `url(/placeholder.svg?height=200&width=200&text=Morocco+${i + 1})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            >
              <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            </div>
          ))}
        </div>

        {/* Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>

        {/* Content */}
        <div className="relative z-10 flex items-center justify-center h-full text-center text-white px-4">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
              Morocco <span className="text-orange-400">Stories</span>
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl mb-4 max-w-3xl mx-auto">
              This itinerary is for the curious. The ones who want to taste the coast, roam ancient medinas, trek
              through canyons, and sip tea with nomads.
            </p>
            <p className="text-lg md:text-xl text-orange-300 mb-8">
              Expect stories. Expect variety. Expect connection.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 text-lg"
                onClick={() => document.getElementById("stories")?.scrollIntoView({ behavior: "smooth" })}
              >
                <ArrowRight className="mr-2 h-5 w-5" />
                Discover Your Story
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-4 text-lg"
              >
                Watch Video
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Tailored for Every Journey */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Tailored for <span className="text-orange-500">Every Journey</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Whether you're planning a romantic getaway, family adventure, or group expedition, we craft experiences
              that resonate with your unique travel style.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Romantic Couples */}
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="h-8 w-8 text-orange-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Romantic Couples</h3>
                <p className="text-gray-600 mb-6">Intimate experiences, private dinners, and romantic desert camps</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Private accommodations
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Romantic dinners
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Couples spa treatments
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Sunset experiences
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Family Adventures */}
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="h-8 w-8 text-orange-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Family Adventures</h3>
                <p className="text-gray-600 mb-6">Kid-friendly activities, family rooms, and educational experiences</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Family-friendly accommodations
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Educational tours
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Safe activities for children
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Flexible schedules
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Group Expeditions */}
            <Card className="text-center p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <UserCheck className="h-8 w-8 text-orange-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Group Expeditions</h3>
                <p className="text-gray-600 mb-6">Team building, group discounts, and shared experiences</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Group discounts
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Team activities
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Shared accommodations
                  </div>
                  <div className="flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                    Group transportation
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Stories */}
      <section id="stories" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our <span className="text-orange-500">Stories</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Each itinerary is carefully crafted and tested by our team of local desert experts in Ouarzazate. Every
              adventure, every moment, every detail is designed to create unforgettable memories.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tourPackages.map((tour) => (
              <Card key={tour.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img src={tour.image || "/placeholder.svg"} alt={tour.title} className="w-full h-48 object-cover" />
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-orange-500 text-white">
                      <Star className="h-3 w-3 mr-1" />
                      {tour.rating}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <Badge className="bg-orange-100 text-orange-800 mb-3 text-xs">{tour.category.toUpperCase()}</Badge>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{tour.title}</h3>
                  <p className="text-orange-600 font-medium mb-3">{tour.subtitle}</p>
                  <p className="text-gray-600 text-sm mb-4">{tour.description}</p>

                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{tour.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>Morocco</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-orange-600">{tour.price}</span>
                      <span className="text-sm text-gray-500 ml-1">per person</span>
                    </div>
                    <Button
                      className="bg-orange-500 hover:bg-orange-600 text-white"
                      onClick={() => handleBookTour(tour)}
                    >
                      Book This Story
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Adventure Activities */}
      <section id="activities" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Adventure <span className="text-orange-500">Activities</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Enhance your Morocco journey with exciting activities and unique experiences. From desert adventures to
              cultural immersion.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activities.map((activity) => (
              <Card key={activity.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={activity.image || "/placeholder.svg"}
                    alt={activity.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge className="bg-orange-500 text-white">
                      <Star className="h-3 w-3 mr-1" />
                      {activity.rating}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <Badge className="bg-orange-100 text-orange-800 mb-3 text-xs">
                    {activity.category.toUpperCase()}
                  </Badge>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{activity.title}</h3>
                  <p className="text-orange-600 font-medium mb-3">{activity.subtitle}</p>
                  <p className="text-gray-600 text-sm mb-4">{activity.description}</p>

                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{activity.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>Morocco</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-orange-600">{activity.price}</span>
                      <span className="text-sm text-gray-500 ml-1">per person</span>
                    </div>
                    <Button
                      className="bg-orange-500 hover:bg-orange-600 text-white"
                      onClick={() => handleBookTour(activity)}
                    >
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Authentic Experiences */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Authentic <span className="text-orange-500">Experiences</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Every journey includes immersive experiences that connect you to Morocco's soul. These aren't just
              activities—they're windows into a way of life.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🐪</span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Camel Trekking</h3>
              <p className="text-gray-600 text-sm">
                Journey into the Sahara on traditional camel caravans, following ancient nomadic routes.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🍃</span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Nomadic Tea Ceremonies</h3>
              <p className="text-gray-600 text-sm">
                Share mint tea with nomadic families in their traditional tents, learning their customs.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">⭐</span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Luxury Desert Camps</h3>
              <p className="text-gray-600 text-sm">
                Sleep under star-filled skies in comfortable desert camps with traditional Berber hospitality.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🏔️</span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Atlas Mountain Passes</h3>
              <p className="text-gray-600 text-sm">
                Cross dramatic mountain passes and visit remote Berber villages in the High Atlas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Where We Recommend */}
      <section id="hotels" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Where We <span className="text-orange-500">Recommend</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We recommend special, intimate depending on the trek and price. From luxury riads to perfect desert camps,
              every stay is part of the story.
            </p>
          </div>

          <div className="space-y-12">
            {/* Group hotels by city */}
            {["Marrakech", "Casablanca", "Fes"].map((city) => (
              <div key={city}>
                <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                  <span className="text-orange-500">📍</span> {city}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {hotels
                    .filter((hotel) => hotel.city === city)
                    .map((hotel) => (
                      <Card key={hotel.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                        <div className="md:flex">
                          <div className="md:w-1/3">
                            <img
                              src={hotel.image || "/placeholder.svg"}
                              alt={hotel.name}
                              className="w-full h-48 md:h-full object-cover"
                            />
                          </div>
                          <div className="md:w-2/3 p-6">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="text-xl font-bold text-gray-900">{hotel.name}</h4>
                              <Badge className="bg-orange-500 text-white">
                                <Star className="h-3 w-3 mr-1" />
                                {hotel.rating}
                              </Badge>
                            </div>
                            <p className="text-gray-600 text-sm mb-4">{hotel.description}</p>
                            <div className="flex flex-wrap gap-2 mb-4">
                              {hotel.amenities.map((amenity, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {amenity}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="text-xl font-bold text-orange-600">{hotel.price}</span>
                                <span className="text-sm text-gray-500 ml-1">per night</span>
                              </div>
                              <Button className="bg-orange-500 hover:bg-orange-600 text-white">Book Hotel</Button>
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Your Moroccan Guide */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Your <span className="text-orange-500">Moroccan Guide</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                We believe a good Moroccan tour isn't about the standard tourist traps. It's about the unexpected
                moments, the authentic connections, and working as a translator at an international location.
              </p>
              <p className="text-gray-600 mb-6">
                What makes Morocco Sahara special? We work with our associates in Ouarzazate and elsewhere. We stay at
                the best and most authentic places throughout the area. It's Morocco with the soul of the Sahara.
              </p>
              <p className="text-gray-600 mb-8">
                From the bustling souks of Marrakech to the endless dunes of the Sahara, to the blue streets of
                Chefchaouen, we'll take you beyond the guidebook and into the heart of Morocco.
              </p>

              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Personalized itineraries from a native Moroccan</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Access to hidden gems and local experiences</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">24/7 support throughout your journey</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span className="text-gray-700">Sustainable and responsible tourism practices</span>
                </div>
              </div>
            </div>
            <div>
              <img
                src="/placeholder.svg?height=500&width=600&text=Moroccan+Guide"
                alt="Your Moroccan Guide"
                className="w-full h-96 object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stories from Our Travelers */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Stories from Our <span className="text-orange-500">Travelers</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Real experiences from real travelers. These are the moments that make every journey special.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="relative overflow-hidden rounded-lg">
                <img
                  src={`/placeholder.svg?height=300&width=300&text=Traveler+${i + 1}`}
                  alt={`Traveler story ${i + 1}`}
                  className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Your Safety & Peace of Mind */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Your Safety & <span className="text-orange-500">Peace of Mind</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Travel confidently knowing your safety and comfort are our highest priorities with comprehensive support
              and local expertise.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Licensed Tour Operator</h3>
              <p className="text-gray-600 text-sm">
                Fully licensed and insured tour operator with years of experience in Morocco tourism.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Safety First</h3>
              <p className="text-gray-600 text-sm">
                Rigorous safety protocols, emergency procedures, and comprehensive travel insurance coverage.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <UserCheck className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Expert Local Guides</h3>
              <p className="text-gray-600 text-sm">
                Professional, certified local guides with deep knowledge of Moroccan culture and history.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">VIP Support</h3>
              <p className="text-gray-600 text-sm">
                24/7 customer support and on-ground assistance throughout your entire journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What's <span className="text-orange-500">Included</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We handle the details so you can focus on the experience. Here's what comes with every Morocco Stories
              tour.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* What's Included */}
            <Card className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                What's Included
              </h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Private modern 4WD vehicle with A/C, fuel, and insurance</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Professional English-speaking driver & Berber guide</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Desert food prepared in the desert, fresh and organic</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Bottled water</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Camel trekking and desert camping</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">Daily sightseeing and excursions</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-3" />
                  <span className="text-gray-700">All entrance fees to major attractions and monuments</span>
                </div>
              </div>
            </Card>

            {/* Not Included */}
            <Card className="p-6">
              <h3 className="text-xl font-bold text-red-600 mb-4 flex items-center">
                <XCircle className="h-5 w-5 mr-2" />
                Not Included
              </h3>
              <div className="space-y-3">
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">International flights</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Travel insurance</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Lunches and dinners in cities (unless specified)</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Tips and gratuities</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Personal expenses and shopping</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Alcoholic beverages and soft drinks (unless specified)</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Optional activities and excursions</span>
                </div>
                <div className="flex items-center">
                  <XCircle className="h-4 w-4 text-red-500 mr-3" />
                  <span className="text-gray-700">Accommodation upgrade costs (single room, etc.)</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked <span className="text-orange-500">Questions</span>
            </h2>
            <p className="text-lg text-gray-600">Everything you need to know about traveling with Morocco Stories</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg">
                <button
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50"
                  onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
                >
                  <span className="font-medium text-gray-900">{faq.question}</span>
                  <ChevronDown
                    className={`h-5 w-5 text-gray-500 transition-transform ${
                      openFAQ === index ? "transform rotate-180" : ""
                    }`}
                  />
                </button>
                {openFAQ === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Let's Make it <span className="text-orange-500">Happen</span>
            </h2>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Ready to start your Morocco adventure? Get in touch with our travel experts and let's create your perfect
              itinerary together.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Morocco Stories</h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-orange-500 mr-4" />
                  <div>
                    <p className="font-medium">Phone</p>
                    <p className="text-gray-300">+34 697 926 348</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-orange-500 mr-4" />
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-gray-300">info@moroccosstories.com</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-6 w-6 text-orange-500 mr-4" />
                  <div>
                    <p className="font-medium">WhatsApp</p>
                    <p className="text-gray-300">Available 24/7 for instant support</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Button
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3"
                  onClick={() => window.open("https://wa.me/34697926348", "_blank")}
                >
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Chat on WhatsApp
                </Button>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h3 className="text-2xl font-bold mb-6">Start Planning Your Story</h3>
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">First Name</label>
                    <Input
                      type="text"
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Your first name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Last Name</label>
                    <Input
                      type="text"
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Your last name"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Phone</label>
                  <Input
                    type="tel"
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Travel Dates</label>
                  <Input
                    type="text"
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="When would you like to travel?"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <Textarea
                    className="bg-gray-800 border-gray-700 text-white"
                    rows={4}
                    placeholder="Tell us about your dream Morocco adventure..."
                  />
                </div>
                <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3">Send Message</Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="text-xl font-bold">Morocco Stories</span>
            </div>
            <div className="text-center md:text-right">
              <p className="text-gray-400 text-sm">© 2024 Morocco Stories. All rights reserved.</p>
              <p className="text-gray-400 text-sm mt-1">Licensed Tour Operator | Sustainable Tourism</p>
            </div>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      <BookingModal
        tour={selectedTour}
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        onProceedToCheckout={handleBookingComplete}
      />
    </div>
  )
}
